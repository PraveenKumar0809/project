import json
import logging

logging.basicConfig(filename='processing.log', level=logging.INFO)

def read_json_file(file_path):
    """Read data from a JSON file."""
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
        return data
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
        return None
    except json.JSONDecodeError:
        logging.error(f"Invalid JSON format in file: {file_path}")
        return None
    except Exception as e:
        logging.error(f"Error reading file: {file_path}. Error: {str(e)}")
        return None

def filter_questions(data, difficulty_level=None, tags=None):
    """Filter questions based on difficulty level and/or tags."""
    filtered_questions = []
    for question in data:
        if (difficulty_level is None or question.get('difficulty_level') == difficulty_level) and \
           (tags is None or any(tag in question.get('tags', []) for tag in tags)):
            filtered_questions.append(question)
    return filtered_questions

def save_to_json(data, file_path):
    """Save data to a new JSON file."""
    try:
        with open(file_path, 'w') as file:
            json.dump(data, file, indent=4)
        logging.info(f"Data saved to {file_path}")
    except Exception as e:
        logging.error(f"Error saving data to {file_path}. Error: {str(e)}")

# Example usage:
if __name__ == "__main__":
    input_file_path = 'D:/q2/interview_questions.json'
    output_file_path = 'D:/q2/filtered_questions.json'
    data = read_json_file(input_file_path)
    if data:
        filtered_questions = filter_questions(data, difficulty_level='intermediate', tags= ["python", "data structures"])
        save_to_json(filtered_questions, output_file_path)
