QUESTION 2:
 To achieve this objective, you can follow these steps:

  1)Read the data from the JSON file.
  2)Implement functions to filter questions based on difficulty level or tags.
  3)Format the filtered questions into a new JSON structure.
  4)Save the formatted data to a new file.
  5)Include error handling and logging for the processing steps.
