interview_questions={"easy":["What is python?","Is python object-orieted or not?","Can python support oops concepts?"],"intermediate":["What are oops concepts?","What is abstraction?","Is list is mmutable?"],"hard":["What is recursion?","What is tuple?","What is dictionary?"]}
def match_profile(can):
    return interview_questions[(can['experience_level']).lower()]
if __name__ == "__main__":
    candidate_profile = {
        'tags': ['python', 'programming'],
        'experience_level': 'EASY'
    }
    print("Questions for Candidates based on profile:")
    for i in match_profile(candidate_profile):
        print("\t",i)
    
