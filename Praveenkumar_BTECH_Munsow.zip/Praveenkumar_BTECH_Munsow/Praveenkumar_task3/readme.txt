
QUESTION 3:
 To accomplish this objective, you can follow these steps:

 1)Define a pre-defined list of interview questions, each associated with tags and difficulty levels.
 2)Develop a function that takes candidate attributes (such as role, experience level) as input.
 3)Based on the input attributes, select relevant questions from the pre-defined list.
 4)Implement simple logic to match candidate attributes with question tags or difficulty levels.
 5)Ensure the system can be easily modified to accommodate new types of questions or candidate attributes.