from flask import Blueprint, request, jsonify
import re

# Create a Blueprint object for user routes
user_bp = Blueprint('user', __name__)

# Mock database (simple Python dictionary)
users_db = {}

@user_bp.route('/register', methods=['POST'])
def register_user():
    # Parse JSON payload
    data = request.json

    # Check if all required fields are present
    if not all(key in data for key in ['username', 'email', 'password']):
        return jsonify({'error': 'Missing required fields'}), 400

    # Basic validation: check email format
    if not re.match(r'^[\w\.-]+@[\w\.-]+$', data['email']):
        return jsonify({'error': 'Invalid email format'}), 400

    # Basic validation: check password length
    if len(data['password']) < 8:
        return jsonify({'error': 'Password must be at least 8 characters long'}), 400

    # Save user information to mock database
    users_db[data['username']] = {
        'email': data['email'],
        'password': data['password']  # Note: Hash or encrypt password before storing in a real application
    }

    # Return success response
    return jsonify({'message': 'User registered successfully'}), 200
