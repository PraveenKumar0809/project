QUESTION 1:

To accomplish this objective, we'll create a Flask route to handle user registration as described. Below is a basic implementation:

 1)Create routes/user.py file
 2)Make sure you have Flask installed. If not, you can install it using pip:
          pip install Flask

 3)Explaination:
    We create a Flask Blueprint named user_bp to organize our routes.
    We define a route /register that accepts POST requests.
    Inside the route function, we parse the JSON payload sent by the user.
    We check if all required fields (username, email, password) are present in the JSON payload.
    We perform basic validation on the email format using a regular expression.
    We ensure that the password is at least 8 characters long.
    If the validation passes, we save the user information to a mock database (users_db).
    Finally, we return appropriate responses for success and failure cases.  
  4)Run the Flask application by executing the following command:
           python app.py
Send POST request by executing the following command:
           python req.py



